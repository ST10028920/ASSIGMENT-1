/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10028920_prog_assigment_1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class ST10028920_Prog_Assigment_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        
        
        while (true)
        {
            System.out.println("STUDENT MANGEMENT APPLICATION");
            System.out.println("*******************************");
            System.out.println("Menu:");
            System.out.println("1. Capture a new student");
            System.out.println("2. Search for a student");
            System.out.println("3. Delete a student");
            System.out.println("4. Print student report");
            System.out.println("5. Exit Application ");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice)
            {
                case 1:
                    addStudent(scanner);
                    break;
                case 2:
                    searchStudent(scanner);
                    break;
                case 3:
                    deleteStudent(scanner);
                    break;
                case 4:
                    viewStudentReport();
                    break;
                case 5:
                    System.out.println("Exiting the application.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");    
            }
        }
    }
    
    private static void addstudent (Scanner scanner)
    {
        System.out.println("Enter studnet name: ");
        String name = scanner.nextLine();
        
        
        int age;
        while (true)
        {
            try {
                System.out.println("Enter student age: ");
                age = scanner.nextInt();
                if (age >= 16) {
                    break;
                } else {
                    System.out.println("Invalid age. Age must be 16 or older.");
                }
            } catch (InputMismatchException e ) {
                System.out.println("Invaild input. Please enter a number. ");
                scanner.next(); //clearing the invaild input
            }
        }
        
        Student student = new Student ();
        int nextStudentId = 0;
        student.setId(nextStudentId++);
        student.getName();
        student.setAge(age);
        // still need to add other student informtion
        
        student.add(student);
        System.out.println("Student details have been succuessfully saved ");
    }
    
    private static void searchStudent (Scanner scanner)
    {
        System.out.println("Enter student ID to search: ");
        int searchId = scanner.nextInt();
        boolean found = false;
        Iterable<Student> students = null;
        
        for (Student student : students )
        {
            if (student.getId() == searchId) {
                System.out.println("Student found: ");
                System.out.println(student.toString());
                found = true;
                break;
            }
            
            if (!found) 
            {
                System.out.println("Student cannot be located");
            }
        }
        

    
        
    
}

    private static void addStudent(Scanner scanner) {
        throw new UnsupportedOperationException("Not supported yet."); 

    }

    private static void deleteStudent (Scanner scanner) {
        throw new UnsupportedOperationException("Not supported yet."); 

    }

    private static void viewStudentReport() {
        throw new UnsupportedOperationException("Not supported yet."); 

    }
}
